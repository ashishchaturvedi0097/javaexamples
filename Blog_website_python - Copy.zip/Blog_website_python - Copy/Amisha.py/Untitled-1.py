

A=open("sample.txt","r")
txet=A.read()
print(" \n output \n",text)
